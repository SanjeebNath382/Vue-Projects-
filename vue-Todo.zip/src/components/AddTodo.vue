<template>
    <div id="add">
        <form @submit="addTodo">
            <input type=text name="title" placeholder="Add Todo" v-model="title"/>
            <input type=submit value="Submit" class="btn"/>
        </form>
    </div>
</template>

<script>
//import uuid from "uuid"
import axios from 'axios'
export default {
    "name":"AddTodo",
    data(){
        return{
            title:''
        }
    },
    methods: {
        addTodo(e) {
            e.preventDefault();
            const newTodo={
               
                title: this.title,
                completed: false
            }
            console.log(newTodo)
            this.$emit('add-todo',newTodo);
            this.title="";
        },
        created:function(){
     //this.show();
     console.log("hummmmmm")
   },
   show() {
     axios.get('https://jsonplaceholder.typicode.com/todos?_limit=5')
      .then(res=> this.todos=res.data)
      .catch(err=>console.log(err))
   },
        
    }
}
</script>

<style scoped>
form{
    display:flex;
}
input[type="text"]{
    flex:10;
    padding: 5px;

}
input[type="submit"]{
    flex:2;
}

</style>