<template>
    <div class="todo-item" v-bind:class= "{'is-complete':todo.completed}">
       
       <p>
           <input type="checkbox" v-on:change="markCompleted"/>
           
           {{todo.title}}
           <button class="del" v-on:click="$emit('del-todo',todo.id)" >X </button>
           
           </p> 
      
    </div>
</template>

<script>
export default {
    name:"TodoItem",
    props:["todo"],
    methods: {
        markCompleted(){
            this.todo.completed = !this.todo.completed;
        }
    }
}
</script>

<style scoped>
.todo-item{
    background: #f4f4f4;
    padding: 10px;
    border-bottom: 1px #ccc dotted;

}
.is-complete{
    text-decoration: line-through;
}
.del{
    background: #ff0000;
    color:#fff;
    border-radius: 60%;
}
</style>