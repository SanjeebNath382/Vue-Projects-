<template>
  <div class="about">
    <h1>This is an about you page</h1>
  </div>
</template>
