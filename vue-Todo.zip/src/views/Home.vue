<template>
  <div id="app" >
    <header class="header" v-on:mounted="show">
        <h1> TodoList </h1>

    </header>
    <span>
      <addTodo v-on:add-todo="addTodo"/><button v-on:click="show" class="btn">Show </button>
    </span>
    
    
    
   <todos v-bind:todos="todos" v-on:del-todo="deletehandler"/>
   
  </div>
</template>

<script>

import todos from "../components/Todos";
//import heading from "./components/layout/Header"
import addTodo from "../components/AddTodo"
import axios from 'axios'
//console.log(this.newTodo);

export default {
  name: 'Home',
  components: {
    // HelloWorld
    todos,
    addTodo
  },
  methods:{
    deletehandler(id){
      axios.delete(`https://jsonplaceholder.typicode.com/todos/${id}`)
      .then(res=>this.todos= this.todos.filter(todo=> todo.id!==res.data.todo.id))
      .catch()
      this.todos= this.todos.filter(todo=> todo.id!==id);
    },
    addTodo(newTodo){
      const {title,completed}= newTodo;
      axios.post("https://jsonplaceholder.typicode.com/todos",{
        title,completed
      }) .then(res=> this.todos= [...this.todos,res.data])
      .catch(err=>console.log(err))
     
      
    },
   show() {
     axios.get('https://jsonplaceholder.typicode.com/todos?_limit=5')
      .then(res=> this.todos=res.data)
      .catch(err=>console.log(err))
   },
   createArrows: function() {
  },
   created(){
     //this.show();
    setTimeout(() => {
      this.show();
    }, 1000);
   }
   
  },
  data(){
    return {
      todos: [
        
      ]
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.header{
    background: #333;
    color: #fff;
    text-align:center;
    padding: 10px;

}
.header a{
    color: #fff;
    padding-right: 5px;
}
.btn{
  display: inline-block;
  border: none;
  background: #555;
  color: #fff;
  padding: 7px 20px;
  cursor: pointer;
}
.btn:hover{
  background: #666;
}
</style>
